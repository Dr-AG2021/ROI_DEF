% This MATLAB code was written by Dr. Atefeh Goshvarpour & Dr. Ateke Goshvarpour 
% for simulating an article entitled:... 
% "Emotion recognition using a novel Granger causality quantifier  
% and combined electrodes of EEG" considering for puplication in:
% "Brain Sciences"
% If you use the code, please cite the article.

clc; close all; clear all;
tic

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Load data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

oo=1;
for q = 1:9
    o=1; 
    s = ['load C:\Total_Deap_signals\s0' int2str(q) ];eval (s);
for qq = 1:40
for j = 1:32
    y1 = data(qq,j,:);
     mm = y1(:);
     % Extracting EEG frequency bands
     [D2(:,j),D3(:,j),D4(:,j),D5(:,j),A5(:,j)] = wav_EEG1 (mm); 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% Gamma %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = D2;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y); % normalization
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3); % Granger causal matrix
    end
end
[b, bb] = find(F >= 60); % Thresholding & Quantification
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_G(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);
%%%%%%%%%%%%%%%%%%%%%%%%%%% Beta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = D3;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_B(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);
%%%%%%%%%%%%%%%%%%%%%%%%%%% Alpha %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = D4;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_A(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);
%%%%%%%%%%%%%%%%%%%%%%%%%%% Theta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = D5;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_T(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);
%%%%%%%%%%%%%%%%%%%%%%%%%%% Delta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = A5;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_D(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);

end
q
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for q = 10:32
    o=1; 
    s = ['load C:\Total_Deap_signals\s' int2str(q) ];eval (s);
for qq = 1:40
for j = 1:32
    y1 = data(qq,j,:);
     mm = y1(:);
     [D2(:,j),D3(:,j),D4(:,j),D5(:,j),A5(:,j)] = wav_EEG1 (mm);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%% Gamma %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = D2;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_G(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);
%%%%%%%%%%%%%%%%%%%%%%%%%%% Beta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = D3;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_B(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);
%%%%%%%%%%%%%%%%%%%%%%%%%%% Alpha %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = D4;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_A(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);
%%%%%%%%%%%%%%%%%%%%%%%%%%% Theta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = D5;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_T(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);
%%%%%%%%%%%%%%%%%%%%%%%%%%% Delta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y2 = A5;

for iq = 1:32
    for qw = 1:32
        x = y2(:,iq);y = y2(:,qw);
        x = normalize_1(x); y = normalize_1(y);
        [F(iq,qw),c_v(iq,qw)] = granger_cause(x,y,.01,3);
    end
end
[b, bb] = find(F >= 60);
A1=0;
for i = 1:length(b)
    A1 = A1+ F(b(i),bb(i));
end
s = ['wall1_D(' int2str(qq) ' ,' int2str(q) ')= A1;'];eval (s);

end
q
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toc
save wall1_A wall1_A
save wall1_B wall1_B
save wall1_G wall1_G
save wall1_T wall1_T
save wall1_D wall1_D