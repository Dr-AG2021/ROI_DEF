function y1 = normalize_1(x)
% This function was written by Dr. Atefeh Goshvarpour & Dr. Ateke Goshvarpour 
% for simulating an article entitled:... 
% "Emotion recognition using a novel Granger causality quantifier  
% and combined electrodes of EEG" considering for puplication in:
% "Brain Sciences"
% If you use the code, please cite the article
V1 = x;
    s = size(V1); s2 = s(1);
    GHW_max=max(V1);
    GHW_min=min(V1);
    A1 = bsxfun(@minus, V1,GHW_min);
    A3 = bsxfun(@minus, GHW_max, GHW_min);
    V3 = bsxfun(@rdivide,A1,A3);
    y1 = V3*2-1;