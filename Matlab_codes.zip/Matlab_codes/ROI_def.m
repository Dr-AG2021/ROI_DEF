function y = ROI_def(x)
% This function was written by Dr. Atefeh Goshvarpour & Dr. Ateke Goshvarpour 
% for simulating an article entitled:... 
% "Emotion recognition using a novel Granger causality quantifier  
% and combined electrodes of EEG" considering for puplication in:
% "Brain Sciences"
% If you use the code, please cite the article
    Ar1 = [1:5];
    Ar2 = [17,18,20:22];
    Ar3 = [6:8,10];
    Ar4 = [23,25,26,28];
    Ar5 = [9,11:14];
    Ar6 = [27,29:32];
    A1 = sum(x(:,Ar1),2);
    A2 = sum(x(:,Ar2),2);
    A3 = sum(x(:,Ar3),2);
    A4 = sum(x(:,Ar4),2);
    A5 = sum(x(:,Ar5),2);
    A6 = sum(x(:,Ar6),2);
    y = [A1 A2 A3 A4 A5 A6];