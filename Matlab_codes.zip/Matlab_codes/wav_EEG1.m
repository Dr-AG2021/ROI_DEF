function [D2,D3,D4,D5,A5] = wav_EEG1 (data1)
%EEG frequency-band Decomposition
% This function was written by Dr. Atefeh Goshvarpour & Dr. Ateke Goshvarpour 
% for simulating an article entitled:... 
% "Emotion recognition using a novel Granger causality quantifier  
% and combined electrodes of EEG" considering for puplication in:
% "Brain Sciences"
% If you use the code, please cite the article
s=data1; % name sampling and load the data first to the command windows, i named it data1

fs = 128;
% Sampling frequency
N=length(s);
waveletFunction = 'db5';
[C,L] = wavedec (s,5,waveletFunction);
D1 = wrcoef('d',C,L,waveletFunction,1); 
D2 = wrcoef('d',C,L,waveletFunction,2); %GAMMA
D3 = wrcoef('d',C,L,waveletFunction,3); %BETA
D4 = wrcoef('d',C,L,waveletFunction,4); %ALPHA
D5 = wrcoef('d',C,L,waveletFunction,5); %THETA
A5 = wrcoef('a',C,L,waveletFunction,5); %DELTA


